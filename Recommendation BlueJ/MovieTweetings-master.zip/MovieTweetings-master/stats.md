#MovieTweetings statistics

Here are some MovieTweetings statistics. Note that these are autocalculated and may not be completely up to date. Any interesting stats missing here? Ping me, and I'll add them!

Metric | Value
--- | ---
Total number of ratings                 | 891,137
Number of unique users                  | 69,616
Number of unique items                  | 36,580
Minimum rating value                    | 0.0
Maximum rating value                    | 10.0
Earliest rating time                    | 2013-02-28 15:38:27
Last rating time                        | 2021-01-25 00:08:39
Maximum number of ratings per user      | 2,875
Maximum number of ratings per item      | 3,103
Number of users with minimum 50 ratings | 3,839
Number of users with minimum 40 ratings | 4,827
Number of users with minimum 30 ratings | 6,368
Number of users with minimum 20 ratings | 8,966
Number of users with minimum 10 ratings | 14,768
Average number of ratings per user      | 13
Average number of ratings per item      | 24
Stats calculation time                  | Mon Jan 25 02:06:48 2021

